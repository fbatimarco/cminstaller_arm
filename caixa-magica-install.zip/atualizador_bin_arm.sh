sudo /home/pi/atualizador_client/zip/atualizador_bin_arm
